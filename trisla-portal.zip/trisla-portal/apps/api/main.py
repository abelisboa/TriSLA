from fastapi import FastAPI

app = FastAPI(title="TriSLA API", version="1.0.0")

@app.get("/")
def root():
    return {"message": "TriSLA API running successfully!"}

@app.get("/status")
def status():
    return {"status": "OK", "module": "SEM-NSMF", "description": "Semantic interface operational"}
