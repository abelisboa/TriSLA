#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
free_port(){ local p="$1"; if lsof -i :"$p" >/dev/null 2>&1; then fuser -k "${p}/tcp" || true; sleep 1; fi }
free_port 5000; free_port 5173
echo "🚀 Iniciando TriSLA Dashboard v3.0 (backend + frontend)"
python3 -m pip install --user -r backend/requirements.txt >/dev/null
( uvicorn backend.main:app --host 0.0.0.0 --port 5000 & echo $! > .backend.pid ) &
sleep 1
cd frontend
if [ ! -d node_modules ]; then npm install --silent; fi
( npm run dev -- --host --port 5173 & echo $! > ../.frontend.pid ) &
sleep 2
cd ..
echo "🔗 UI: http://localhost:5173   |   API: http://localhost:5000"
trap 'kill -9 $(cat .backend.pid .frontend.pid 2>/dev/null) >/dev/null 2>&1 || true; rm -f .backend.pid .frontend.pid' INT TERM
wait
