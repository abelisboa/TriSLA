#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ -f .env.tunnels ]]; then
  export $(grep -v '^#' .env.tunnels | xargs -d '\n')
fi

if ! command -v uvicorn >/dev/null 2>&1; then
  echo "⚠️  uvicorn não encontrado. Instalando requisitos..."
  pip3 install --user -r backend/requirements.txt
fi
nohup python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 5000 > backend.log 2>&1 &
BPID=$!
echo "✅ Backend PID: $BPID"

pushd frontend >/dev/null
if [[ ! -d node_modules ]]; then
  echo "⚠️  Instalando dependências do frontend..."
  npm i --silent
fi
nohup npx vite --port 5173 --host > ../frontend.log 2>&1 &
FPID=$!
popd >/dev/null
echo "✅ Frontend PID: $FPID"

echo "🔗 UI: http://localhost:5173   |   API: http://localhost:5000"
