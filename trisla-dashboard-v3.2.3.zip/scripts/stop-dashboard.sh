#!/usr/bin/env bash
set -euo pipefail

pkill -f "npx vite" || true
pkill -f "vite-node" || true
pkill -f "uvicorn backend.main:app" || true

for p in 9091 9092 9093 8088 8090 8092; do
  lsof -ti tcp:$p | xargs -r kill -9 || true
done

echo "✅ Tudo encerrado."
