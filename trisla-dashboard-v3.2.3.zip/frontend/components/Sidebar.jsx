import React from 'react';
import { NavLink } from 'react-router-dom';

export default function Sidebar({status}){
  return (
    <div className="sidebar">
      <h1>TriSLA Dashboard</h1>
      <NavLink to="/" end className={({isActive})=> isActive ? 'active' : ''}>Overview</NavLink>
      <NavLink to="/metrics" className={({isActive})=> isActive ? 'active' : ''}>Metrics</NavLink>
      <NavLink to="/slices-npl" className={({isActive})=> isActive ? 'active' : ''}>Create Slice (NPL)</NavLink>
      <NavLink to="/slices-gst" className={({isActive})=> isActive ? 'active' : ''}>Create Slice (GST)</NavLink>
      <div className="status">
        Prometheus: <b>{status.prometheus}</b><br/>
        SEM-NSMF: <b>{status.sem_nsmf}</b>
      </div>
    </div>
  );
}
