# TriSLA Dashboard v3.2.3

## Quick Start
```bash
unzip trisla-dashboard-v3.2.3.zip
cd trisla-dashboard-v3.2.3

# 1) Connect NASP (creates remote kubectl port-forwards + local SSH tunnels)
bash scripts/connect-trisla-nasp-v3.2.3.sh

# 2) Start backend + frontend
pip3 install --user -r backend/requirements.txt
bash scripts/start-dashboard.sh

# 3) Stop everything
bash scripts/stop-dashboard.sh
```
