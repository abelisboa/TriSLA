import os
from typing import Any, Dict
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import httpx

PROMETHEUS_URL = os.getenv("PROMETHEUS_URL", "http://localhost:9091")
SEM_NSMF_URL   = os.getenv("SEM_NSMF_URL",   "http://localhost:8088")

app = FastAPI(title="TriSLA Dashboard API", version="3.2.3")

origins = ["http://localhost:5173", "http://127.0.0.1:5173"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/status")
async def api_status():
    prom_ok = False
    sem_ok = False
    async with httpx.AsyncClient(timeout=3.0) as client:
        try:
            r = await client.get(f"{PROMETHEUS_URL}/-/ready")
            prom_ok = r.status_code == 200 and "Ready" in r.text
        except Exception:
            prom_ok = False
        try:
            r2 = await client.get(f"{SEM_NSMF_URL}/api/v1/health")
            sem_ok = r2.status_code == 200
        except Exception:
            sem_ok = False
    return {
        "version": "3.2.3",
        "prometheus": "online" if prom_ok else "offline",
        "sem_nsmf": "online" if sem_ok else "offline",
        "prometheus_url": PROMETHEUS_URL,
        "sem_nsmf_url": SEM_NSMF_URL,
    }

@app.get("/api/promql/query")
async def prom_query(query: str = Query(...)):
    async with httpx.AsyncClient(timeout=10.0) as client:
        r = await client.get(f"{PROMETHEUS_URL}/api/v1/query", params={"query": query})
        return r.json()

@app.get("/api/promql/query_range")
async def prom_query_range(query: str, start: float, end: float, step: str = "15s"):
    params = {"query": query, "start": start, "end": end, "step": step}
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.get(f"{PROMETHEUS_URL}/api/v1/query_range", params=params)
        return r.json()

@app.post("/api/slices/npl")
async def create_slice_npl(payload: Dict[str, Any]):
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.post(f"{SEM_NSMF_URL}/api/v1/slices/npl", json=payload)
            return r.json()
        except Exception as e:
            raise HTTPException(502, f"SEM-NSMF unreachable: {e}")

@app.post("/api/slices/gst")
async def create_slice_gst(payload: Dict[str, Any]):
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.post(f"{SEM_NSMF_URL}/api/v1/slices/gst", json=payload)
            return r.json()
        except Exception as e:
            raise HTTPException(502, f"SEM-NSMF unreachable: {e}")
