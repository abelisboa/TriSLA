import React,{useState} from 'react';const API=import.meta.env.VITE_API_URL||'http://localhost:5000'
export default function SliceFormGST(){const [form,setForm]=useState<any>({serviceName:'Telemedicina',serviceType:'URLLC',latency:'1ms',throughput:'100Mbps',availability:'99.99%',domains:['RAN','Transport','Core']});const [resp,setResp]=useState<any>(null);const [loading,setLoading]=useState(false);
const upd=(k:string,v:any)=>setForm((s:any)=>({...s,[k]:v}));const submit=async()=>{setLoading(true);try{const r=await fetch(`${API}/api/slices/gst/submit`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});const d=await r.json();setResp(d);}finally{setLoading(false);}};
return(<div className="bg-white rounded-xl shadow-soft p-6">
  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div><label className="text-sm text-gray-600">Nome do Serviço</label><input className="w-full border rounded-lg p-2" value={form.serviceName} onChange={e=>upd('serviceName',e.target.value)}/></div>
    <div><label className="text-sm text-gray-600">Tipo (URLLC/eMBB/mMTC)</label><input className="w-full border rounded-lg p-2" value={form.serviceType} onChange={e=>upd('serviceType',e.target.value)}/></div>
    <div><label className="text-sm text-gray-600">Latência</label><input className="w-full border rounded-lg p-2" value={form.latency||''} onChange={e=>upd('latency',e.target.value)}/></div>
    <div><label className="text-sm text-gray-600">Throughput</label><input className="w-full border rounded-lg p-2" value={form.throughput||''} onChange={e=>upd('throughput',e.target.value)}/></div>
    <div><label className="text-sm text-gray-600">Disponibilidade</label><input className="w-full border rounded-lg p-2" value={form.availability||''} onChange={e=>upd('availability',e.target.value)}/></div>
    <div><label className="text-sm text-gray-600">Domínios</label><input className="w-full border rounded-lg p-2" value={form.domains.join(',')} onChange={e=>upd('domains',e.target.value.split(',').map((x:string)=>x.trim()))}/></div>
  </div>
  <div className="mt-3"><button onClick={submit} className="px-4 py-2 rounded-lg bg-sidebar text-white">{loading?'Validando...':'Validar & Gerar NEST'}</button></div>
  {resp&&(<pre className="mt-4 bg-gray-50 p-3 rounded-lg overflow-auto text-sm">{JSON.stringify(resp,null,2)}</pre>)}
</div>)}
