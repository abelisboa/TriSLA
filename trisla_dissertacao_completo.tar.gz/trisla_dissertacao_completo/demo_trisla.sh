#!/bin/bash
echo "=== DEMONSTRAÇÃO TriSLA@NASP ==="
echo "1. Verificando status do sistema..."
kubectl get pods -n trisla-nsp

echo -e "\n2. Executando cenário URLLC..."
kubectl exec -n trisla-nsp deploy/sem-nsmf -- python3 -c "
import urllib.request
import json
data = json.dumps({'name': 'demo-urllc', 'type': 'URLLC', 'requirements': {'latency': 10, 'reliability': 99.9}}).encode('utf-8')
req = urllib.request.Request('http://sem-nsmf:8080/api/v1/slices', data=data, headers={'Content-Type': 'application/json'})
response = urllib.request.urlopen(req)
result = json.loads(response.read().decode('utf-8'))
print('Resultado:', result)
"

echo -e "\n3. Acessos disponíveis:"
echo "- API: http://localhost:30800/api/v1/health"
echo "- Grafana: http://localhost:3000"
echo "- Prometheus: http://localhost:9090"
