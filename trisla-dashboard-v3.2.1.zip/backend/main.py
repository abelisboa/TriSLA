from fastapi import FastAPI
import httpx, os

app = FastAPI(title="TriSLA Dashboard Backend", version="3.2.1")

PROM_PORTS = [int(os.getenv("PROM_PORT_FALLBACK", "9090")), 9091, 9092]
SEM_PORTS = [int(os.getenv("SEM_PORT_FALLBACK", "8080")), 8088, 8090]

async def check_url(url):
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(url)
            if r.status_code == 200 and any(k in r.text.lower() for k in ["ok", "running", "ready"]):
                return True
    except Exception:
        pass
    return False

@app.get("/api/status")
async def status():
    prom_online = any([await check_url(f"http://localhost:{p}/-/ready") for p in PROM_PORTS])
    sem_online = any([await check_url(f"http://localhost:{p}/api/v1/health") for p in SEM_PORTS])
    return {
        "prometheus": "online" if prom_online else "offline",
        "sem_nsmf": "online" if sem_online else "offline",
        "ml_nsmf": "unknown",
        "bc_nssmf": "unknown"
    }
