import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";

function App() {
  const [status, setStatus] = useState({prometheus: "unknown", sem_nsmf: "unknown"});
  async function refresh() {
    try {
      const r = await fetch("http://localhost:5000/api/status");
      const j = await r.json();
      setStatus(j);
    } catch {}
  }
  useEffect(() => { refresh(); const id = setInterval(refresh, 8000); return () => clearInterval(id); }, []);
  const badge = (name, ok) => (<div style={{display:"flex",justifyContent:"space-between"}}><span>{name}</span><span style={{color:ok?"#7CFC00":"#ff8080"}}>{ok?"online":"offline"}</span></div>);
  return (
    <div style={{display:"flex",minHeight:"100vh",background:"#0b1730",color:"#e6eefc"}}>
      <div style={{width:"240px",padding:"18px",background:"#0a1a38",borderRight:"1px solid #123"}}>
        <h2>TriSLA</h2>
        <button disabled={status.sem_nsmf!=="online"}>Criar Slice (NPL)</button><br/>
        <button disabled={status.sem_nsmf!=="online"}>Criar Slice (GST)</button><br/>
        <button disabled={status.prometheus!=="online"}>Ver Métricas</button>
        <div style={{marginTop:"12px"}}>{badge("Prometheus",status.prometheus==="online")}{badge("SEM-NSMF",status.sem_nsmf==="online")}</div>
      </div>
      <div style={{padding:"20px"}}>
        <h1>TriSLA Dashboard v3.2.1</h1>
        <p>Atualiza a cada 8s automaticamente.</p>
      </div>
    </div>
  );
}
createRoot(document.getElementById("root")).render(<App />);
