# TriSLA Dashboard v3.1.3

Conector e scripts para operar o Dashboard local integrado ao NASP (Prometheus + SEM-NSMF).

## Uso rápido

```bash
# 1) Conectar NASP (cria túnel Prometheus e SEM-NSMF)
bash scripts/connect-trisla-nasp-v3.1.3.sh

# 2) Subir dashboard (se você tiver backend/frontend locais)
bash scripts/start-dashboard.sh

# 3) Encerrar tudo
bash scripts/stop-dashboard.sh
```

## Pré-requisitos

- SSH funcionando com `ppgca.unisinos.br` e salto para `node1` (via `~/.ssh/config`).
- `kubectl` acessível no `node1` e serviços instalados:
  - `prometheus-kube-prometheus-prometheus` (normalmente no namespace `monitoring`)
  - `sem-nsmf` (no namespace `trisla-nsp`, porta 8080)

## Notas

- O conector detecta automaticamente namespace, serviço e portas livres (fallback 9090→9091→9092; 8080→8088→8090).
- Health check do SEM-NSMF usa `/api/v1/health` por padrão; tenta também `/health`, `/status`, `/api/health`.
- Logs dos port-forwards remotos ficam em `/tmp/*-pf.log` no `node1`.
