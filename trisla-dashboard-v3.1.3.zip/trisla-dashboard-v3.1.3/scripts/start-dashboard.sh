#!/usr/bin/env bash
set -euo pipefail
echo "🚀 Iniciando TriSLA Dashboard (backend + frontend)"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Backend (se existir um main:app FastAPI)
if [ -f "backend/main.py" ]; then
  if ! command -v uvicorn >/dev/null 2>&1; then
    echo "⚠️  uvicorn não encontrado. Instale com: pip install --user uvicorn fastapi"
  else
    echo "▶️  Subindo backend (uvicorn)..."
    nohup uvicorn backend.main:app --host 0.0.0.0 --port 5000 >/tmp/trisla-backend.log 2>&1 &
    echo "✅ Backend em :5000"
  fi
fi

# Frontend (se existir um projeto Vite/React)
if [ -d "frontend" ] && [ -f "frontend/package.json" ]; then
  echo "▶️  Subindo frontend (Vite)..."
  (cd frontend && nohup npm run dev >/tmp/trisla-frontend.log 2>&1 &)
  echo "✅ Frontend (Vite) iniciado"
fi

echo "🔗 UI: http://localhost:5173   |   API: http://localhost:5000"
