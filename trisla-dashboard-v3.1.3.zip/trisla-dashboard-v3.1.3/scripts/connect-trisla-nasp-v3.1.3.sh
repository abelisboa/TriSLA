#!/usr/bin/env bash
# ======================================================
# TriSLA / NASP - Conector resiliente Prometheus + SEM-NSMF (v3.1.3)
# Autor: Abel Lisboa
# Data: 2025-11-02
# ======================================================
set -euo pipefail

# -------- Config (ajustável) --------
JUMP_HOST="${JUMP_HOST:-ppgca.unisinos.br}"         # nome do host jump (mapeado no ~/.ssh/config)
NASP_HOST="${NASP_HOST:-node1}"                      # host interno (apelido que aponta para node006)
PROM_CANDIDATE_SVC="${PROM_CANDIDATE_SVC:-prometheus-kube-prometheus-prometheus}"
PROM_NAMESPACE_HINT="${PROM_NAMESPACE_HINT:-monitoring}"
SEM_NAMESPACE_HINT="${SEM_NAMESPACE_HINT:-trisla-nsp}"
SEM_CANDIDATE_SVC="${SEM_CANDIDATE_SVC:-sem-nsmf}"

# Portas locais preferidas (o script testa fallback se ocupadas)
PROM_LOCAL_PORTS=(9090 9091 9092)
SEM_LOCAL_PORTS=(8080 8088 8090)

# Endpoint de saúde do SEM-NSMF (detectado automaticamente, mas já deixamos padrão)
SEM_HEALTH_CANDIDATES=(/api/v1/health /health /status /api/health)

# -------- Cores --------
RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; BLU=$'\e[34m'; RST=$'\e[0m'

log() { echo -e "$1"; }

port_free() {
  local port="$1"
  if command -v lsof >/dev/null 2>&1; then
    ! lsof -i :"$port" >/dev/null 2>&1
  else
    # fallback
    ! fuser "$port"/tcp >/dev/null 2>&1
  fi
}

pick_free_port() {
  local -n arr=$1
  for p in "${arr[@]}"; do
    if port_free "$p"; then echo "$p"; return 0; fi
  done
  return 1
}

ssh_exec() {
  # Usa ProxyCommand/ProxyJump conforme ~/.ssh/config; não force usuário aqui
  ssh -o BatchMode=yes -J "$JUMP_HOST" "$NASP_HOST" "$@"
}

start_remote_pf() {
  local ns="$1" svc="$2" rport="$3" name="$4"
  # Mata forwards antigos para o mesmo serviço/porta
  ssh_exec "pgrep -a kubectl | grep 'port-forward' | grep 'svc/${svc} ' | awk '{print \$1}' | xargs -r kill -9 || true"
  # Inicia novo port-forward remoto
  ssh_exec "nohup kubectl -n ${ns} port-forward svc/${svc} ${rport}:${rport} --address 127.0.0.1 >/tmp/${name}-pf.log 2>&1 & disown"
}

start_local_tunnel() {
  local lport="$1" rport="$2"
  # Se porta local está ocupada, libera
  if ! port_free "$lport"; then
    fuser -k "${lport}"/tcp >/dev/null 2>&1 || true
    sleep 0.5
  fi
  # Inicia túnel local → remoto via jump
  ssh -f -N -L "${lport}:127.0.0.1:${rport}" -J "$JUMP_HOST" "$NASP_HOST"
}

detect_prom() {
  # Detecta namespace real do Prometheus e confirma porta 9090
  local ns
  ns=$(ssh_exec "kubectl get svc -A | awk '/${PROM_CANDIDATE_SVC}/{print \$1}' | head -n1")
  if [[ -z "$ns" ]]; then ns="$PROM_NAMESPACE_HINT"; fi
  echo "$ns"
}

detect_sem() {
  # Retorna: "<namespace> <service> <port>"
  local line ns svc port
  line=$(ssh_exec "kubectl get svc -A | awk '/${SEM_CANDIDATE_SVC}/{print \$1, \$2, \$5}' | head -n1")
  if [[ -z "$line" ]]; then
    # fallback — tenta qualquer serviço com 'semantic'
    line=$(ssh_exec "kubectl get svc -A | awk '/semantic/{print \$1, \$2, \$5}' | head -n1")
  fi
  if [[ -z "$line" ]]; then
    echo ""
    return 1
  fi
  ns=$(echo "$line" | awk '{print $1}')
  svc=$(echo "$line" | awk '{print $2}')
  port=$(echo "$line" | awk '{print $3}' | sed 's#/TCP##' | cut -d',' -f1)
  echo "$ns $svc $port"
}

http_ok() {
  local url="$1"
  curl -m 3 -fsS "$url" >/dev/null 2>&1
}

health_sem() {
  local base="http://127.0.0.1:$1"
  for ep in "${SEM_HEALTH_CANDIDATES[@]}"; do
    if curl -m 3 -fsS "${base}${ep}" | grep -qiE 'ok|running|ready|phase'; then
      echo "$ep"; return 0
    fi
  done
  return 1
}

main() {
  log "${BLU}======================================================${RST}"
  log "${BLU}🚇  Conector TriSLA ↔ NASP (Prometheus + SEM-NSMF) v3.1.3${RST}"
  log "${BLU}======================================================${RST}"

  log "🔍 Verificando conexão SSH via jump host..."
  if ! ssh -o BatchMode=yes -J "$JUMP_HOST" "$NASP_HOST" "hostname" >/dev/null 2>&1; then
    log "${RED}❌ Falha: não foi possível conectar a ${NASP_HOST} via ${JUMP_HOST}${RST}"
    exit 1
  fi
  log "✅ SSH operacional."

  # ---------- PROMETHEUS ----------
  local prom_ns prom_lport
  prom_ns="$(detect_prom)"
  log "🧩 Procurando Prometheus (${PROM_CANDIDATE_SVC})... namespace candidato: ${prom_ns}"
  # Confirma que o svc existe
  if ! ssh_exec "kubectl -n ${prom_ns} get svc ${PROM_CANDIDATE_SVC}" >/dev/null 2>&1; then
    log "${RED}⚠️  Serviço Prometheus '${PROM_CANDIDATE_SVC}' não encontrado em ${prom_ns}${RST}"
  else
    prom_lport="$(pick_free_port PROM_LOCAL_PORTS || echo 9090)"
    log "🌐 Iniciando port-forward remoto de ${PROM_CANDIDATE_SVC} (porta 9090) em ${prom_ns}..."
    start_remote_pf "${prom_ns}" "${PROM_CANDIDATE_SVC}" 9090 "prometheus"

    log "🔁 Criando túnel local → remoto na porta ${prom_lport} (→ 9090)..."
    start_local_tunnel "${prom_lport}" 9090

    if http_ok "http://127.0.0.1:${prom_lport}/-/ready"; then
      log "🟢 Prometheus online em http://localhost:${prom_lport}"
    else
      log "🔴 Prometheus não respondeu em http://localhost:${prom_lport}"
    fi
  fi

  # ---------- SEM-NSMF ----------
  log "🧩 Detectando SEM-NSMF..."
  local sem_info sem_ns sem_svc sem_rport sem_lport sem_ep
  sem_info="$(detect_sem || true)"
  if [[ -z "${sem_info}" ]]; then
    log "${RED}⚠️  SEM-NSMF não encontrado no cluster (svc=${SEM_CANDIDATE_SVC}).${RST}"
  else
    sem_ns="$(echo "${sem_info}" | awk '{print $1}')"
    sem_svc="$(echo "${sem_info}" | awk '{print $2}')"
    sem_rport="$(echo "${sem_info}" | awk '{print $3}')"
    if [[ -z "${sem_ns}" ]]; then sem_ns="${SEM_NAMESPACE_HINT}"; fi
    log "🧠 SEM-NSMF detectado: ns=${sem_ns} svc=${sem_svc} porta=${sem_rport}"

    sem_lport="$(pick_free_port SEM_LOCAL_PORTS || echo 8080)"
    log "🌐 Iniciando port-forward remoto de ${sem_svc} (${sem_rport}) em ${sem_ns}..."
    start_remote_pf "${sem_ns}" "${sem_svc}" "${sem_rport}" "sem-nsmf"

    log "🔁 Criando túnel local → remoto na porta ${sem_lport} (→ ${sem_rport})..."
    start_local_tunnel "${sem_lport}" "${sem_rport}"
    sleep 1

    sem_ep="$(health_sem "${sem_lport}" || true)"
    if [[ -n "${sem_ep:-}" ]]; then
      log "🟢 SEM-NSMF online em http://localhost:${sem_lport}${sem_ep}"
    else
      log "🔴 SEM-NSMF offline em http://localhost:${sem_lport} (não respondeu health)."
      log "   Dica: teste manual os endpoints: ${SEM_HEALTH_CANDIDATES[*]}"
    fi
  fi

  log "✅ Finalizado."
}

main "$@"
