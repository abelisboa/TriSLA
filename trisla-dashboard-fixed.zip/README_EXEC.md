# TriSLA Dashboard (fixed)

## Menu
Edite seu `dashboard-menu.sh` para chamar:
```bash
bash ./scripts/start-dashboard.sh
```

## Variáveis
Crie `.env` em `backend/` se precisar mudar o Prometheus:
```
PROMETHEUS_URL=http://localhost:9090
```

## Port-forward Prometheus
```bash
kubectl -n monitoring port-forward svc/prometheus-kube-prometheus-prometheus 9090:9090
# ou
./scripts-wsl/start-ssh-tunnel.sh
```
