import React from 'react'
export default function Metrics() {
  return <div className="bg-white rounded-xl shadow-soft p-6">Métricas detalhadas (em breve)</div>
}
