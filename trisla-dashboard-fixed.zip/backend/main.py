
import os
import asyncio
from datetime import datetime
from typing import Any, Dict

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

PROMETHEUS_URL = os.getenv("PROMETHEUS_URL", "http://localhost:9090")

app = FastAPI(title="TriSLA Dashboard API", version="1.0.0", description="Proxy API para Prometheus e TriSLA")

origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PromQuery(BaseModel):
    query: str

@app.get("/")
async def root():
    return {"service": "trisla-dashboard-backend", "version": "1.0.0"}

@app.get("/health")
async def health_backend():
    return {
        "status": "ok",
        "service": "trisla-dashboard-backend",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "prometheus": "unknown",
    }

@app.get("/api/prometheus/health")
async def health_prometheus():
    url = f"{PROMETHEUS_URL}/-/ready"
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            r = await client.get(url)
            ok = r.status_code == 200
            return {
                "status": "ok" if ok else "error",
                "prometheus": "ready" if ok else "not-ready",
                "code": r.status_code,
                "url": url,
            }
    except Exception as e:
        return {
            "status": "error",
            "prometheus": "unreachable",
            "error": str(e),
            "url": url,
        }

async def _prom_query(query: str) -> Dict[str, Any]:
    url = f"{PROMETHEUS_URL}/api/v1/query"
    params = {"query": query}
    async with httpx.AsyncClient(timeout=10.0) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        return r.json()

@app.post("/api/prometheus/query")
async def prom_query(body: PromQuery):
    try:
        return await _prom_query(body.query)
    except httpx.HTTPError as e:
        raise HTTPException(status_code=502, detail=f"Prometheus error: {e}")

@app.get("/api/prometheus/metrics/system")
async def metrics_system():
    cpu_q = 'avg(rate(process_cpu_seconds_total[1m])) * 100'
    mem_q = 'sum(process_resident_memory_bytes) / 1024 / 1024'
    results = {"cpu": None, "memory_mb": None}

    try:
        data_cpu, data_mem = await asyncio.gather(_prom_query(cpu_q), _prom_query(mem_q))
        def val(d):
            try:
                return float(d["data"]["result"][0]["value"][1])
            except Exception:
                return None
        results["cpu"] = val(data_cpu)
        results["memory_mb"] = val(data_mem)
    except Exception:
        pass

    return {
        "status": "ok",
        "cpu_avg": results["cpu"],
        "memory_mb": results["memory_mb"],
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

@app.get("/api/prometheus/metrics/timeseries")
async def metrics_timeseries(metric: str = Query(default="process_cpu_seconds_total")):
    end = int(datetime.utcnow().timestamp())
    start = end - 300
    step = 5
    url = f"{PROMETHEUS_URL}/api/v1/query_range"
    params = {
        "query": f"rate({metric}[1m])",
        "start": start,
        "end": end,
        "step": step,
    }
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            return r.json()
    except Exception as e:
        return {"status": "error", "error": str(e), "url": url, "params": params}
