#!/bin/bash
set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ROOT="$(dirname "$DIR")"

echo "🚀 Iniciando TriSLA Dashboard (backend + frontend)"
echo "📦 Raiz: $ROOT"

pushd "$ROOT/backend" >/dev/null
python3 -m pip install --upgrade pip >/dev/null
pip3 install -r requirements.txt >/dev/null
uvicorn main:app --host 0.0.0.0 --port 5000 &
BACK_PID=$!
popd >/dev/null

sleep 2

pushd "$ROOT/frontend" >/dev/null
npm install >/dev/null
npm run dev >/dev/null &
FRONT_PID=$!
popd >/dev/null

echo "✅ Backend PID: $BACK_PID  |  Frontend PID: $FRONT_PID"
echo "🔗 UI: http://localhost:5173   |   API: http://localhost:5000"

trap "echo '🛑 Encerrando...'; kill $BACK_PID $FRONT_PID" EXIT
wait
