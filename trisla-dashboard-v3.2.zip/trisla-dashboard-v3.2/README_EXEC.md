# TriSLA Dashboard v3.2

- Conector v3.2 com validações extras (jobs/npl/gst).
- Backend FastAPI com `/api/status` para o frontend decidir quando habilitar ações.
- Frontend mínimo com menu lateral, status e botões condicionais.

## Uso
```bash
unzip trisla-dashboard-v3.2.zip
cd trisla-dashboard-v3.2

# 1) Conectar NASP
bash scripts/connect-trisla-nasp-v3.2.sh

# 2) Iniciar backend e frontend
bash scripts/start-dashboard.sh

# 3) Encerrar
bash scripts/stop-dashboard.sh
```
