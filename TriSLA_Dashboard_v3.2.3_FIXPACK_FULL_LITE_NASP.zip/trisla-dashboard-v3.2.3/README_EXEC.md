# TriSLA Dashboard v3.2.3 – FIXPACK FULL LITE NASP

## 🚀 Execução
1. Conecte-se ao NASP:
   ```bash
   bash scripts/connect-trisla-nasp-v3.2.3.sh
   ```

2. Suba backend + frontend:
   ```bash
   bash scripts/start-dashboard.sh
   ```

3. Encerrar tudo:
   ```bash
   bash scripts/stop-dashboard.sh
   ```

## 🌐 Endpoints
- UI: http://localhost:5174
- API: http://localhost:8000
