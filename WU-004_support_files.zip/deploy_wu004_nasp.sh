#!/bin/bash
# =====================================================
# 🚀 TriSLA — WU-004 NASP Auto Deploy Script
# =====================================================
# Executa automaticamente o rollout e validação no cluster NASP
# Autor: Abel Lisboa | Data: $(date +"%Y-%m-%d")
# =====================================================

set -e
NS="trisla-nsp"
PACKAGE="WU-004_package.zip"
DEPLOY_DIR="./WU-004_package"
LOG_FILE="WU-004_DEPLOY_STATUS.log"

echo "====================================================="
echo " 🧩 TriSLA — Deploy Automático (NASP)"
echo "====================================================="
echo "📦 Pacote: ${PACKAGE}"
echo "📂 Diretório destino: ${DEPLOY_DIR}"
echo "🕒 Início: $(date)"
echo "====================================================="

# 1️⃣ Descompactar o pacote
if [ -f "${PACKAGE}" ]; then
  echo "📦 Descompactando pacote..."
  unzip -o ${PACKAGE} -d ${DEPLOY_DIR} > /dev/null
else
  echo "❌ Pacote ${PACKAGE} não encontrado."
  exit 1
fi

# 2️⃣ Reiniciar deployments
echo "🔄 Reiniciando módulos..."
for MODULE in ai semantic integration blockchain monitoring; do
  DEPLOY="trisla-${MODULE}-layer"
  kubectl rollout restart deployment ${DEPLOY} -n ${NS}
done

# 3️⃣ Aguardar estabilização
echo "⏳ Aguardando pods ficarem prontos..."
sleep 20
kubectl get pods -n ${NS} > ${LOG_FILE}

# 4️⃣ Validar conectividade AI → Semantic
AI_POD=$(kubectl get pod -n ${NS} -l app=trisla-ai-layer -o jsonpath='{.items[0].metadata.name}')
echo "🔍 Validando comunicação entre módulos..."
kubectl exec -it ${AI_POD} -n ${NS} -- curl -s trisla-semantic-svc:8080/health >> ${LOG_FILE} || echo "❌ Falha no healthcheck" >> ${LOG_FILE}

# 5️⃣ Mostrar status final
echo "====================================================="
echo "✅ Deploy concluído em $(date)"
echo "📜 Log salvo em: ${LOG_FILE}"
echo "====================================================="

kubectl get pods -n ${NS}
