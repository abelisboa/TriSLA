# TriSLA Dashboard v3.2.2

Pacote com pasta-raiz corrigida, CORS habilitado no backend, fallback de portas e conector NASP robusto.

## Uso rápido
```bash
unzip trisla-dashboard-v3.2.2.zip
cd trisla-dashboard-v3.2.2

# 1) Conectar NASP (túneis Prometheus/SEM-NSMF, auto-fallback)
bash scripts/connect-trisla-nasp-v3.2.2.sh

# 2) Subir backend + frontend
pip3 install --user -r backend/requirements.txt
bash scripts/start-dashboard.sh

# 3) Encerrar
bash scripts/stop-dashboard.sh
```
