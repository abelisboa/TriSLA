#!/bin/bash
# Inicializa estrutura TriSLA Portal
# (FastAPI + React + Helm)
echo 'Criando estrutura TriSLA Portal...'