#!/bin/bash
echo 'Build & Push das imagens para GHCR'